# Python Exceptions
This directory contains tasks on handling python exceptions
