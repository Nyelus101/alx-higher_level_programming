#!/usr/bin/python3
def raise_exception():
    """Raises a type exception"""

    raise TypeError
